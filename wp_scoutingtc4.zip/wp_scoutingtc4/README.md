# Scouting TC4 WordPress theme

Installatie: upload `scoutingtc4-wordpress.zip` via WordPress > Weergave > Thema’s > Nieuw thema > Thema uploaden.

Na activeren:
1. Maak een menu aan en koppel dit aan locatie **Hoofdmenu**.
2. Stel logo, kleuren, headertekst, telefoonnummer, contact-URL en socials in via **Customizer > Scouting TC4 opties**.
3. Gebruik widgets/blokken in de gebieden Hero, Featured A/B/C, Showcase, Nieuws, Sidebar, Bottom A/B en Footer.

Let op: dit is een WordPress-theme conversie van de Joomla-template. Joomla-modules zijn niet één-op-één mee te nemen; hun posities zijn omgezet naar WordPress-widgetgebieden.



## Homepage 2020 gebruiken

- Kies bij de homepage het template `Homepagina 2020`.
- Gebruik de metabox `Slider` onder de editor om slides toe te voegen.
- Voeg in de blok-editor losse blokken toe:
  - `Featured items`
  - `Callout`
  - `Nieuws items`
  - `Twee kolommen`


## Callout bestaande afbeeldingen

In het blok `Callout` kun je bij `Bestaande afbeelding` kiezen uit:
- Bijl
- Kompas

Kies je daarna een eigen afbeelding, dan wordt de preset automatisch uitgezet.


## Homepagina vullen met velden

Open de homepage en gebruik de metabox `Homepagina onderdelen`.

Zet `Homepagina onderdelen tonen vanuit deze velden` aan. Daarna wordt de homepage opgebouwd uit:
- Featured items
- Callout
- Intro tekst
- Nieuws items
- Twee kolommen

Dit werkt naast de bestaande slider metabox.


## Vanaf 1.1.3

Alleen de slideshow staat nog onder de editor.

Homepage-onderdelen worden als blokken direct in de editor aangepast:
- Featured items
- Callout
- Nieuws items
- Twee kolommen

Zoek de blokken onder categorie `Scouting TC4`.


## 1.1.4

Het blok `Featured items` wordt in de editor nu getoond als ACF-achtig invoerformulier:
- Kop
- Items
- Beeld
- Tekst
- Knop met tekst, URL en kleur


## 1.1.5

In het blok `Featured items` is het veld `Tekst` nu een rijke tekst-editor met ondersteuning voor o.a. vet, cursief en links.


## 1.1.6

Het rijke tekstveld in `Featured items` is gecorrigeerd zodat het tekstvlak aanklikbaar en bewerkbaar is.


## 1.1.7

Het tekstveld in `Featured items` heeft nu een klassieke editor-achtige toolbar boven het veld, vergelijkbaar met de oude WordPress/ACF invoer.


## 1.1.8

Het klassieke tekstveld in `Featured items` gebruikt nu een stabiele Gutenberg RichText-editor. Plakken van tekst laat het blok niet meer verdwijnen.


## 1.1.9

Het tekstveld in `Featured items` is vereenvoudigd naar een directe RichText-zone. De klassieke toolbar is alleen visueel; tekst bewerken en plakken gebeurt in het grote witte tekstvlak.


## 1.2.0

De teksteditor in `Featured items` is vervangen door een stabiele klassieke editor met toolbar zoals de gewenste invoer. Plakken wordt veilig afgehandeld zodat het blok niet verdwijnt.


## 1.2.1

Frontend-opmaak van `Featured items` afgestemd op het voorbeeld:
- drie kolommen
- groene Roboto Slab koppen
- vaste afbeeldingverhouding
- blauwe pill-knoppen met pijl
- Snel naar-lijst met ronde pijl-iconen


## 1.2.2

Het blok `Callout` heeft nu dezelfde formulierstijl als de oude versie:
- Eigen beeld gebruiken ja/nee
- Beeldlijst: bijl, boei, gps, haken, hout, kompas, lamp, touw, zaklamp, zakmes
- Titel
- Tekst met klassieke editor
- Knop met tekst, URL en kleur


## 1.2.3

Callout frontend aangepast naar de stijl van het oude template:
- skyline bovenaan
- bewegende skyline-animatie
- groene callout-balk
- callout-afbeelding en tekst uitgelijnd zoals voorbeeld
- zwarte knop met pijl


## 1.2.4

Callout-tekst wordt nu altijd gerenderd en expliciet zichtbaar gemaakt. Als een bestaand blok geen tekstwaarde opslaat, wordt de standaardtekst gebruikt.


## 1.2.5

Callout verder gefinetuned:
- afbeelding groter gezet
- afbeelding iets lager gepositioneerd
- tekstkolom iets lager uitgelijnd
- skyline animatie vertraagd zoals in oude template


## 1.2.6

Skyline-animatie in de callout aangepast:
- beweegt zichtbaar van links naar rechts
- animatieduur teruggezet naar 120 seconden


## 1.2.7

Het blok `Nieuws items` heeft nu een ACF-achtige editor:
- eerst categorieën aanvinken
- daarna nieuwsitems selecteren
- gekozen nieuwsitems worden als labels/tokens getoond


## 1.2.8

Frontend-opmaak van `Nieuws items` aangepast naar het voorbeeld:
- groene titelbalk onder de afbeelding
- datum als witte overlay op de afbeelding
- excerpt onder de titelbalk
- blauwe knop `Meer nieuws`


## 1.2.9

Nieuwsblok frontend verder gelijk gezet aan het oude theme:
- oude HTML-structuur van beeld + groene titelbalk
- h5-titel terug in de groene balk
- datumoverlay en excerpt afgestemd
- knop Meer nieuws behouden


## 1.3.0

Laatste finetune op het nieuwsblok:
- vaste hoogte voor groene titelvlakken
- kortere excerpt
- betere verticale uitlijning
- knop `Meer nieuws` dichter bij oude thema-opmaak


## 1.3.1

Blok `Twee kolommen` aangepast naar formulierstijl zoals de oude versie:
- Kolom 1: beeld, kop, tekst, knop
- Kolom 2: kop, WYSIWYG-editor, knop


## 1.3.2

Frontend van `Twee kolommen` verder afgestemd op het voorbeeld:
- titel links in de afbeelding
- lichtgroen tekstvlak links
- rechter kolom met groene rand
- WYSIWYG-koppen groen
- knopopmaak en afstanden dichter bij het oude thema


## 1.3.3

Twee kolommen verder gecorrigeerd:
- rechter titel mag weer afbreken en toont niet meer `Vacat...`
- WYSIWYG-content rechts wordt weer volledig getoond
- linker en rechter kolom volgen beter de oude lay-out
- knoppen en tekstafstanden verder gefinetuned


## 1.3.4

Breedte van `Twee kolommen` gecorrigeerd:
- blok krijgt nu ongeveer dezelfde totale breedte als in het oude thema
- beide kolommen vullen meer ruimte
- minder smalle weergave op desktop


## 1.3.5

Overlap in `Twee kolommen` opgelost:
- buitenste blok is geen grid meer
- alleen de binnenste `.gb-two-columns` bepaalt de twee kolommen
- kolommen overlappen niet meer


## 1.3.6

Twee kolommen gecorrigeerd:
- rechterkolomtekst rendert weer correct
- fallback-tekst toegevoegd voor oude blokdata zonder inhoud
- knop pijl opnieuw opgebouwd met CSS in plaats van een teken


## 1.3.7

Slider/video aangepast:
- bij Type `video` kun je nu een video uit de WordPress mediabibliotheek kiezen
- bibliotheekvideo wordt autoplay/muted/loop/playsinline als banner getoond
- externe video URL blijft beschikbaar als fallback


## 1.3.8

Videobanner uitgebreid:
- nieuw veld `Kop over video`
- kop wordt gecentreerd over de videobanner getoond
- werkt voor bibliotheekvideo en externe video-embed


## 1.3.9

Typografie gelijkgetrokken met het oude Scouting 2020 template:
- basisfont Poppins
- koppen Roboto Slab
- bannerkop Urban Jungle
- tekstgrootte en regelhoogte homepageblokken afgestemd
- knoppenfont en groottes afgestemd


## 1.4.0

Header aangepast naar het oude template:
- logo/stempel links over de banner
- witte menubalk van 84px hoog
- melding vóór het menu
- actieve groene balk boven menu-item
- iconen rechts in volgorde telefoon, contact, zoeken
- hamburger alleen op kleinere schermen of als desktop-hamburger actief is


## 1.4.1

Header gecorrigeerd:
- melding staat nu direct links van menu
- menu blijft blauw, hover groen
- alleen actuele menu-item krijgt groene lijn
- iconen rechts blijven blauw
- logo/stempel opnieuw gepositioneerd


## 1.4.2

Header-menu aangepast:
- tekstkleur van het menu en de iconen volgt nu de steunkleur
- groene/hoofdkleur-balkje verschijnt alleen bij actief menu-item
- balkje verschijnt ook bij hover/focus, zoals in het oude template


## 1.4.3

Header-menu balkje gefixt:
- balkje is standaard echt verborgen
- zichtbaar bij actief item
- zichtbaar bij hover/focus
- extra correctie voor Bootstrap `.active`


## 1.4.4

Header-balkje definitief gecorrigeerd:
- `.active` en ancestor classes tonen geen balkje meer
- alleen echte current-menu-item/current_page_item
- hover/focus toont tijdelijk een balkje


## 1.4.5

Header-balkje volledig opnieuw opgebouwd:
- alle oude pseudo-elements, borders en backgrounds voor balkjes uitgeschakeld
- nieuwe gecontroleerde indicator via `li::after`
- zichtbaar alleen bij huidige pagina of hover/focus


## 1.4.6

Header-balkje dunner gezet:
- hoogte teruggebracht naar 3px
- extra oude pseudo-lines expliciet uitgeschakeld


## 1.4.7

Header dropdown gecorrigeerd:
- submenu opent nu onder de menubalk
- submenu valt niet meer over het hoofdmenu heen
- dropdown-items krijgen geen groene menu-indicator


## 1.4.8

Header-iconen gelijkgetrokken met oude template:
- Font Awesome toegevoegd
- telefoon, envelop, zoeken en hamburger gebruiken nu Font Awesome
- SVG-iconen vervangen


## 1.4.9

Font Awesome iconen exact gelijkgezet met oude template:
- `fas fa-exclamation-triangle`
- `fas fa-phone`
- `fas fa-envelope`
- `fas fa-search`
- `fa fa-bars`


## 1.5.0

Header-uitlijning gelijkgetrokken met oude template:
- vaste 84px headerhoogte
- logo/stempel exact links gepositioneerd
- melding, menu en iconen op één horizontale lijn
- menu-items verticaal gecentreerd
- iconen met vaste spacing en centrering
- dropdown start onder volledige header


## 1.5.1

Mobiele header aangepast:
- mobiel/tablet toont alleen logo en hamburger
- melding, menu-items en iconen staan in een Bootstrap offcanvas
- desktopheader blijft ongewijzigd


## 1.5.2

Footer aangepast naar oude template-stijl:
- grasrand boven de footer
- groene hoofdfooter met social media en copyright links
- partnerblok rechts
- witte onderbalk met footermenu
- nieuwe menu-locatie `Footermenu`


## 1.5.3

Footermenu aangepast:
- witte footermenu-balk wordt alleen getoond als er een menu aan `Footermenu` is toegewezen
- geen fallback-links meer


## 1.5.4

Footermenu gecorrigeerd:
- menu-items onderaan worden nu expliciet in de hoofdkleur/groen weergegeven
- Bootstrap/WordPress witte linkkleur wordt overschreven


## 1.5.5

`Partners van Scouting` is nu een eigen widgetgebied:
- nieuwe widget area: `Footer - Partners van Scouting`
- het partnerblok wordt alleen getoond als deze widget area inhoud heeft
- geen hardcoded partnerlogo's meer


## 1.5.6

Footer-gras uitgebreid:
- geanimeerde vlinder toegevoegd die over het gras voorbij vliegt
- animatie loopt automatisch en herhaalt eindeloos
- mobiel iets kleiner/snellere cyclus


## 1.5.7

Vlinder in de footer aangepast:
- CSS-vlinder vervangen door een vaste SVG-vlinder
- vorm en kleur afgestemd op de gele vlinder zoals op scouting.nl
- vlieg-animatie behouden


## 1.5.8

Vlinder opnieuw opgebouwd:
- HTML-structuur gelijkgetrokken met scouting.nl:
  - `.butterfly__container`
  - `.butterfly__wrapper`
  - `.butterfly`
  - `.wing`
  - `.bit`
  - `.shadow`
- animatie en opbouw nu gebaseerd op dezelfde componentstructuur


## 1.5.9

Butterfly CSS vervangen door de aangeleverde scouting.nl CSS:
- body, wings, bits en shadow volgen nu dezelfde CSS-opbouw
- leftflap/rightflap/shadow keyframes toegevoegd
- fly-by animatie over footergras behouden


## 1.6.0

Vlinderweergave gecorrigeerd:
- vleugels staan nu rond één middenpunt
- niet langer twee losse vlinders naast elkaar
- schaal en positie in gras verfijnd


## 1.6.1

Vlinder-vliegstand aangepast:
- vlinder vliegt nu gekanteld/schuin
- traject roteert licht mee tijdens het vliegen
- meer overeenkomst met scouting.nl


## 1.6.2

Vlinder opgeschoond:
- alle eerdere butterfly-overrides verwijderd
- opnieuw opgebouwd op basis van de originele scouting.nl CSS
- één middenpunt voor de vleugels
- wrapper zorgt alleen voor schaal, kanteling en fly-by


## 1.6.3

Vlinder verder gecorrigeerd:
- lijf expliciet zichtbaar gemaakt
- backface flicker/knipperen verminderd
- .wing-achtergrond transparant gezet
- vliegstand gedraaid zodat de vlinder niet achteruit lijkt te vliegen


## 1.6.4

Vlinder verder aangepast op basis van het aangeleverde filmpje:
- vlinder staat schuin in de vliegrichting
- lijf en kop blijven zichtbaar
- extra graslaag over de vlinder zodat hij achter het gras door vliegt
- vliegpad en bobbing afgestemd op het voorbeeld


## 1.6.5

Vlinder opnieuw verfijnd:
- vliegt sneller voorbij
- lager geplaatst zodat hij achter het gras beweegt
- lijf slanker en zichtbaarder gemaakt
- vleugels transparanter gemaakt


## 1.6.6

Vlinder-snelheid aangepast:
- desktop fly-by vertraagd naar 13.5s
- mobiel vertraagd naar 11.5s


## 1.6.7

Vlinderpositie aangepast:
- vlinder vliegt nu voor het gras
- z-index van de vlinder verhoogd
- gras-overlay blijft aanwezig maar ligt achter de vlinder


## 1.6.8

Vlinderschaduw aangepast:
- schaduw staat nu recht onder de vlinder
- scheve horizontale offset verwijderd
- shadow keyframes mee aangepast


## 1.6.9

Vlinder volledig verwijderd:
- HTML uit footer verwijderd
- CSS/animaties verwijderd
- eventuele vlinder-assets verwijderd


## 1.7.0

Desktop-hamburgermenu gecorrigeerd:
- desktop-hamburger opent nu ook het offcanvas-menu
- gewone menu-items en iconen worden niet meer onder elkaar onder de header getoond
- header toont bij desktop-hamburger alleen logo en hamburger


## 1.7.1

Desktop-hamburger aangepast:
- melding blijft zichtbaar in de header
- menu-items en iconen blijven verborgen in de header
- offcanvas blijft het menu tonen


## 1.7.2

Thema-instelling toegevoegd:
- nieuwe optie `Header breedte`
- keuze tussen `Smal` en `Breed`
- smal = oude template-header
- breed = scouting.nl-achtige header met compactere balk, logo centraal/over banner en offcanvas-menu


## 1.7.3

Header breedte instelling beter zichtbaar gemaakt:
- nieuwe Customizer-sectie `Header layout`
- optie `Header breedte` staat nu onder deze sectie
- sectie heeft vaste prioriteit zodat hij zichtbaar is in de Customizer


## 1.7.4

Header breedte betekenis gecorrigeerd:
- `Smal` = scouting.nl-achtige header
- `Breed` = oude template-header


## 1.7.5

Smalle/scouting.nl header gecorrigeerd:
- logo wordt niet meer in het midden van de pagina geplaatst
- logo staat nu links binnen de contentbreedte zoals bij scouting.nl
- logoformaat iets gecorrigeerd


## 1.7.6

Smal/scouting.nl-header verder gecorrigeerd:
- headerinhoud gecentreerd op vaste contentbreedte
- logo links over de banner geplaatst zoals in voorbeeld
- melding, iconen en menu rechts uitgelijnd binnen dezelfde breedte
- compacte 64px headerhoogte behouden


## 1.7.7

Smalle header gelijkgetrokken met brede/oude variant:
- headerhoogte nu ook 84px
- logo/stempel gebruikt hetzelfde formaat en dezelfde positionering
- content padding-top aangepast naar 84px


## 1.7.8

Logo/stempel gecorrigeerd:
- logo wordt nu exact gecentreerd binnen de stempel
- vaste top/left offsets vervangen door 50% centrering
- optische verticale centrering aangepast zodat tekst en beeld samen mooi in de stempel vallen


## 1.7.9

Logo/stempel gecorrigeerd volgens de originele TC4-template:
- logo-container 250x250
- stempel geplaatst zoals background-position: right -25px
- logo gecentreerd met max-width 150px
- werkt voor smalle en brede header


## 1.8.0

Mobiele header aangepast:
- stempel wordt op mobiel/tablet niet meer getoond
- logo staat nu als normaal logo in de header
- offcanvas toont geen stempel


## 1.8.1

Brede/oude header aangepast:
- tekst `Menu` wordt nu ook naast het hamburgericoon getoond wanneer desktop-hamburger actief is


## 1.8.2

Customizer afsluiten gecorrigeerd:
- voorkomt dat de native file-uploadknop `Een bestand selecteren` als losse overlay zichtbaar blijft
- custom logo/media-controls blijven bruikbaar
- cleanup wordt uitgevoerd bij sluiten van de Customizer


## 1.8.3

Customizer file-input melding strenger gecorrigeerd:
- losse `input[type=file]` buiten het Customizer-paneel worden gemarkeerd en verborgen
- media/logo-controls binnen de Customizer blijven bruikbaar
- MutationObserver toegevoegd zodat later toegevoegde losse file-inputs ook worden verborgen


## 1.8.4

Admin upload-theme fix toegevoegd:
- specifiek voor `/wp-admin/update.php?action=upload-theme`
- verbergt losse native file-inputs op de theme overwrite/update pagina
- staat los van de eerdere Customizer-fix


## 1.8.5

Sterkere update.php?action=upload-theme fix:
- directe admin_head/admin_footer output toegevoegd
- werkt op basis van de URL, niet alleen op admin_enqueue_scripts
- file-input wordt meerdere keren en via MutationObserver verborgen


## 1.8.6

Update.php upload-theme cleanup:
- verbergt de losse `Een bestand selecteren` uploadinterface op update.php?action=upload-theme
- toont korte terugstuurmelding
- stuurt automatisch terug naar `Weergave > Thema's`


## 1.8.7

Thema opgeschoond:
- tijdelijke Customizer-fixes verwijderd
- tijdelijke `update.php?action=upload-theme` fixes verwijderd
- geen admin/file-input workarounds meer in het thema
